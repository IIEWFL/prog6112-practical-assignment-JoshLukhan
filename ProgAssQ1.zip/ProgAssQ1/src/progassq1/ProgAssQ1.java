/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progassq1;

import java.util.Scanner;
import static progassq1.Student.deleteStudent;
import static progassq1.Student.saveStudent;
import static progassq1.Student.searchStudent;
import static progassq1.Student.studentReport;

/**
 *
 * @author Josh
 */
public class ProgAssQ1 {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        int choice; // Declared varible for users choice
        
        
    //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=B7AEJvEhmXo 
    //Neil Gillies

        do {
            System.out.println("\n STUDENT MANAGEMENT APLLICATION:");
            System.out.println("1. Capture a new Student");
            System.out.println("2. Search for a student"); //Menu system layout 
            System.out.println("3. Delete a student");
            System.out.println("4. Print student report");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    saveStudent(scanner);
                    break;
                case 2:
                    searchStudent(scanner);     //Switch statment which calls the corresponding method based on user input 
                    break;
                case 3:
                    deleteStudent(scanner);
                    break;
                case 4:
                    studentReport();
                    break;
                case 0:
                    System.out.println("Exiting Application...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0); //will do everything as long as choice is not 0
    }
    }
    

