/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progassq1;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Josh
 */
public class Student {
    
    public static ArrayList<String> studentNames = new ArrayList<>();
    public static ArrayList<String> studentEmails = new ArrayList<>();
    public static ArrayList<String> studentIDs = new ArrayList<>();     //Declaring the array lists which stores the students details
    public static ArrayList<Integer> studentAges = new ArrayList<>();
    public static ArrayList<String> studentCourses = new ArrayList<>();
    
    //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=yHvQVc0WUF4&t=457s
    //Alex Lee
    
     public static void saveStudent(Scanner scanner) {
        System.out.print("Enter Student name: ");
        String studentName = scanner.nextLine(); //asking the user for input and storing in the corresponding array list
        studentNames.add(studentName);

        System.out.print("Enter Student email: "); //asking the user for input and storing in the corresponding array list
        String studentEmail = scanner.nextLine();
        studentEmails.add(studentEmail);

        System.out.print("Enter Student ID: ");
       String studentID = scanner.nextLine(); //asking the user for input and storing in the corresponding array list
        studentIDs.add(studentID);
        
        System.out.print("Enter Student course: "); //asking the user for input and storing in the corresponding array list
        String studentCourse = scanner.nextLine();
        studentCourses.add(studentCourse);
        
        while (true) {
            System.out.print("Please enter your age: ");
            
            // Check if the input is an integer
            if (scanner.hasNextInt()) {
              int  age = scanner.nextInt();
                
                // Check if age is greater than or equal to 16
                if (age >= 16) {
                    
                    studentAges.add(age);
                    break; // Exit loop if age is valid
                } else {
                    System.out.println("Age must be 16 or older. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer.");
                scanner.next(); 
            }
        }
        
        System.out.println("Student information captured successfully.");
    }
        
     
     //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=bbdrmbmSaW0
    //Dinesh Varyani
     
     
    public static void searchStudent(Scanner scanner) { //Method to search for the student using the student ID
        System.out.print("Enter Student  ID to search: ");
        String studID = scanner.nextLine();

        for (int i = 0; i < studentIDs.size(); i++) { //using for loop to itterate
            if (studentIDs.get(i).equalsIgnoreCase(studID)) {
                System.out.println("Student found:");
                System.out.println("Student Name: " + studentNames.get(i) +
                        ", Student email: " + studentEmails.get(i) +
                        ", Student ID: " + studentIDs.get(i) + 
                        ", Student age: " + studentAges.get(i) +
                        ", Student Course: " + studentCourses.get(i));
                return;
            }
        }
        System.out.println("Student not found."); //output
    }

    

    public static void deleteStudent(Scanner scanner) { // method to delete student using the student ID
        System.out.print("Enter Student ID to delete: ");
        String studID = scanner.nextLine();
        int index = studentIDs.indexOf(studID);
        if(index != -1){
        
        System.out.println("Are you sure you want to delete Student?: " + studID + " ,Type yes to delete.");
        String confirmation = scanner.nextLine(); //asking for confirmation 
        if(confirmation.equalsIgnoreCase("yes")){
            
             for (int i = 0; i < studentNames.size(); i++) { //for loop to itterate through the array lists and remove the matching index
            if (studentIDs.get(i).equalsIgnoreCase(studID)) {
                studentEmails.remove(i);
                studentNames.remove(i);
                studentIDs.remove(i);
                studentAges.remove(i);
                studentCourses.remove(i);
                System.out.println("Student with ID: " + studID + " was deleted successfully.");
                return;
        }else{
                
                System.out.println("Deletion Cancelled");  
            }
             }
        
        }else{
            
         System.out.println("Student not found.");   
        }
        }
 
    }

    public static void studentReport() { //method to display the students information
        System.out.println("\nAll Student Information:");
        for (int i = 0; i < studentNames.size(); i++) { //for loop to itterate and and print
            System.out.println("------------------------------------");
            System.out.println(" Student Name: " + studentNames.get(i) + "\n" +
                    " Student Email: " + studentEmails.get(i) + "\n" +
                    " Student ID: " + studentIDs.get(i) + "\n" +
                    " Student Age: " + studentAges.get(i) + "\n" +
                    " Student Course: " + studentCourses.get(i));
             System.out.println("------------------------------------");
        }
    }
    
   
    
    }
    
    
    
    
    

