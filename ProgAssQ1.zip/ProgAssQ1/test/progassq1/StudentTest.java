/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progassq1;

import java.util.ArrayList;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Josh
 */
public class StudentTest {
    
    public StudentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of saveStudent method, of class Student.
     */
    @Test
    public void testSaveStudent() {
        
       String studentData = "John Doe\njohn@example.com\n12345\nComputer Science\n20\n";
        Scanner scanner = new Scanner(studentData);
        Student.saveStudent(scanner);
        assertEquals(1, Student.studentNames.size());
        assertEquals("John Doe", Student.studentNames.get(0));
        assertEquals("john@example.com", Student.studentEmails.get(0));
        assertEquals("12345", Student.studentIDs.get(0));
        assertEquals("Computer Science", Student.studentCourses.get(0));
        assertEquals(20, Student.studentAges.get(0));
    }

    /**
     * Test of searchStudent method, of class Student.
     */
    @Test
    public void testSearchStudent() {
       
        Student.studentNames.add("Jane Smith");
        Student.studentEmails.add("jane@example.com");
        Student.studentIDs.add("54321");
        Student.studentAges.add(21);
        Student.studentCourses.add("Math");

        // Prepare input
        String searchData = "54321\n";
        Scanner scanner = new Scanner(searchData);

        // Test if the correct student details are returned
        Student.searchStudent(scanner);
        
        
    }
    
    
    @Test
   public void testSearchStudent_StudentNotFound() {
        // Prepare input
        String searchData = "99999\n";
        Scanner scanner = new Scanner(searchData);

        // Test if no student is found
        Student.searchStudent(scanner);

        // Check console for "Student not found." message (can refactor method to return value for better testing)
    }

    /**
     * Test of deleteStudent method, of class Student.
     */
    @Test
    public void testDeleteStudent() {
        
        Student.studentNames.add("Emily Davis");
        Student.studentEmails.add("emily@example.com");
        Student.studentIDs.add("98765");
        Student.studentAges.add(22);
        Student.studentCourses.add("Physics");

        // Prepare input
        String deleteData = "98765\nyes\n";
        Scanner scanner = new Scanner(deleteData);

        // Call delete method
        Student.deleteStudent(scanner);

        // Assertions to check if the student has been deleted
        assertEquals(0, Student.studentNames.size());
        
        
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Prepare input
        String deleteData = "00000\nyes\n";
        Scanner scanner = new Scanner(deleteData);

        // Test deletion with incorrect ID
        Student.deleteStudent(scanner);

        // Check console for "Student not found." message (can refactor method to return value for better testing)
    }

    @Test
   public void testStudentAge_StudentAgeValid() {
        // Prepare input
        String ageData = "17\n";
        Scanner scanner = new Scanner(ageData);

        // Simulate saving a student with valid age
        String studentData = "Student Name\nstudent@example.com\nID001\nCourse\n";
        Scanner studentScanner = new Scanner(studentData + ageData);

        // Call save method
        Student.saveStudent(studentScanner);

        // Assert age is saved correctly
        
    }

    @Test
   public void testStudentAge_StudentAgeInvalid() {
        // Prepare input with age < 16
        String invalidAgeData = "15\n";
        Scanner scanner = new Scanner(invalidAgeData);

        // Simulate saving a student with invalid age
        String studentData = "Student Name\nstudent@example.com\nID002\nCourse\n";
        Scanner studentScanner = new Scanner(studentData + invalidAgeData);

        // Call save method
        Student.saveStudent(studentScanner);

        // Assert the age hasn't been saved due to invalid entry
        assertTrue(Student.studentAges.isEmpty()); // Age shouldn't have been added
    }

    @Test
   public void testStudentAge_StudentAgeInvalidCharacter() {
        // Prepare input with invalid characters for age
        String invalidCharacterData = "invalid\n17\n"; // Input a non-integer first, followed by a valid age
        Scanner scanner = new Scanner(invalidCharacterData);

        // Simulate saving a student with invalid character for age
        String studentData = "Student Name\nstudent@example.com\nID003\nCourse\n";
        Scanner studentScanner = new Scanner(studentData + invalidCharacterData);

        // Call save method
        Student.saveStudent(studentScanner);

        // Assert the correct age (17) was eventually saved
        
    }
    
    
}
