/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question.pkg2;

/**
 *
 * @author Josh
 
 */

    //Code Attribution
    //This method was taken from w3schools
    //https://www.w3schools.com/java/java_abstract.asp
    //w3schools

abstract class Employee {
    
     //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=zbVAU7lK25Q
    //Alex Lee
    
    private String name;
    private int employeeId;
    protected double salary;  // declaring protected variables for access in subclasses

    // Constructor to initialise variables
    public Employee(String name, int employeeId) {
        this.name = name;
        this.employeeId = employeeId;
    }

    // Get method to get the name and employee ID
    public String getName() {
        return name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    // Abstract method to calculate salary
    public abstract double calculateSalary();

    // Report method to print employee details
    public void report() {
        System.out.println("Employee ID: " + employeeId + ", Name: " + name + ", Salary: $" + calculateSalary());
    }
    
    
    
    
    
    
    
    
    
}
