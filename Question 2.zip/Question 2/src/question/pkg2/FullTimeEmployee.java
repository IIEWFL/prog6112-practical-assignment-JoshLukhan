/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question.pkg2;

/**
 *
 * @author Josh
 */
 class FullTimeEmployee extends Employee {
    
    
     private double basicSalary;

    // Constructor
    public FullTimeEmployee(String name, int employeeId, double basicSalary) {
        super(name, employeeId);
        this.basicSalary = basicSalary;
    }

    // Calculate salary for full-time employee
    
    //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=u4YcW-ex7Yk
    //Alex Lee
    
    
    @Override
    public double calculateSalary() {
        return basicSalary;
    }
     
}
