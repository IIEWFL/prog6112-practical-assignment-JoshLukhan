/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question.pkg2;

/**
 *
 * @author Josh
 */
 class PartTimeEmployee extends Employee {
    
     
     
     private double hoursWorked;
    private double hourlyRate;

    
    //Code Attribution
    //This method was taken from "Youtube"
    //https://www.youtube.com/watch?v=hLYOpvoM4vk
    //Alex Lee
    
    // Constructor
    public PartTimeEmployee(String name, int employeeId, double hoursWorked, double hourlyRate) {
        super(name, employeeId);
        this.hoursWorked = hoursWorked;
        this.hourlyRate = hourlyRate;
    }

    // Calculate salary for part-time employee
    @Override
    public double calculateSalary() {
        return hoursWorked * hourlyRate;
    }
     
     
     
     
     
     
}
