/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package question.pkg2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Josh
 */
 class PayrollSystem {
    
    
    private ArrayList<Employee> employees = new ArrayList<>();

    // Adding employee to the system thorugh the array list
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Generate payroll report for employees
    public void generateReport() {
        System.out.println("Payroll Report:");
        for (Employee employee : employees) {
            employee.report();
        }
    }

    // Input employees into the system
    public void inputEmployeeData() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of employees:"); //getting input
        int n = scanner.nextInt();

        for (int i = 0; i < n; i++) {
            System.out.println("Enter 1 for Full-Time Employee, 2 for Part-Time Employee:"); //getting input
            int type = scanner.nextInt();
            scanner.nextLine();  

            System.out.println("Enter Employee Name:"); //getting input
            String name = scanner.nextLine();
            System.out.println("Enter Employee ID:");
            int id = scanner.nextInt();

            if (type == 1) {
                System.out.println("Enter Basic Salary:"); //getting input
                double basicSalary = scanner.nextDouble();
                FullTimeEmployee ftEmployee = new FullTimeEmployee(name, id, basicSalary);
                addEmployee(ftEmployee);
            } else if (type == 2) {
                System.out.println("Enter Hours Worked:"); //getting input
                double hoursWorked = scanner.nextDouble();
                System.out.println("Enter Hourly Rate:");
                double hourlyRate = scanner.nextDouble();
                PartTimeEmployee ptEmployee = new PartTimeEmployee(name, id, hoursWorked, hourlyRate);
                addEmployee(ptEmployee);
            }
        }
    
    
    
    
    
    
}
 }
