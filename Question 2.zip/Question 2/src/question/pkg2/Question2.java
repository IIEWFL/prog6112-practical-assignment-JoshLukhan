/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package question.pkg2;

/**
 *
 * @author Josh
 */
public class Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        // calling the methods 
        PayrollSystem payrollSystem = new PayrollSystem();
        payrollSystem.inputEmployeeData();
        payrollSystem.generateReport();
 
    }
}
