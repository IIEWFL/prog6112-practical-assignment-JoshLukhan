/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package question.pkg2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Josh
 */
public class Question2Test {
    private FullTimeEmployee fullTimeEmployee;
    private PartTimeEmployee partTimeEmployee;
    public Question2Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        fullTimeEmployee = new FullTimeEmployee("John Doe", 1, 5000.0);
        partTimeEmployee = new PartTimeEmployee("Jane Doe", 2, 20, 15.0);
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Question2.
     */
    @Test
    public void testFullTimeEmployeeSalary() {
        assertEquals(5000.0, fullTimeEmployee.calculateSalary(), 0.01);
    }

    @Test
    public void testPartTimeEmployeeSalary() {
        assertEquals(300.0, partTimeEmployee.calculateSalary(), 0.01);
    }
    
}
